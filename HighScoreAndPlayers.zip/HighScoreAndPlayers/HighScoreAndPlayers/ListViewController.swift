//
//  ViewController.swift
//  HighScoreAndPlayers
//
//  Created by T3ll0 on 4/16/16.
//  Copyright © 2016 E.V.I.L. All rights reserved.
//

import UIKit

class ListViewController: UITableViewController, AddItemDelegate ,UsePlayerDelegate{
    

    
    var items : [Player] = []
    var ip : NSIndexPath?
    required init?(coder aDecoder: NSCoder) {
       
        
        //create array items
        items = [Player]()
        
        let item = Player()
        item.name = "Yoni"
        
       // items.append(item)
        super.init(coder: aDecoder)
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //////////////////////////////////////////////////////////////////////////
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    //////////////////////////////////////////////////////////////////////////
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("ListItem", forIndexPath: indexPath)
        updateCellWithItem(cell, item: items[indexPath.row])
        return cell
    }
    
    //////////////////////////////////////////////////////////////////////////
    func updateCellWithItem(cell: UITableViewCell, item: Player){
        let label = cell.viewWithTag(100) as! UILabel
        label.text = item.name
        let label2 = cell.viewWithTag(200) as! UILabel
        label2.text = String(item.score)
        
        
    }
    
    //////////////////////////////////////////////////////////////////////////
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print("holo")
        ip = indexPath
        let storyboard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
        let destination = storyboard.instantiateViewControllerWithIdentifier("Game") as! ViewController
        destination.playero = items[indexPath.row]
        destination.UPD = self
        destination.ip = ip
       // navigationController?.pushViewController(destination, animated: true)
         presentViewController(destination, animated: true, completion: nil) 
    }
    
    //////////////////////////////////////////////////////////////////////////
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        items.removeAtIndex(indexPath.row)//UpdateModel
        let indexpaths = [indexPath]
        tableView.deleteRowsAtIndexPaths(indexpaths, withRowAnimation: .Fade)
    }
    
    ////////////////////Delegated add player/////////////////////////
     func addItemDelegateCancel(controller: AddPlayerTableViewController) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    func addItemDelegateDone(controller: AddPlayerTableViewController, finishingAddingItem itm: Player) {
        dismissViewControllerAnimated(true, completion: nil)
        let newItem = itm
        
        let indexitem = items.count
        items.append(newItem)
        let indexPath = NSIndexPath(forRow: indexitem, inSection: 0)
        tableView.insertRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
    }
    
    //////////////////////////////////////////////////////////////////////////

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "addPlayer"{
            let navigatorController =  segue.destinationViewController as! UINavigationController
            let controller = navigatorController.topViewController as! AddPlayerTableViewController
            controller.delegate = self
        }
         if segue.identifier == "gameSegue"{
            let controller =  segue.destinationViewController as! ViewController
            controller.UPD = self
            controller.ip = ip

        }
    }
    //////////////////////////////////////////////////////////////////////////
    func ModifyPlayerCancel(controller: ViewController,player: Player, ip:NSIndexPath){
        controller.dismissViewControllerAnimated(true, completion: nil)

        print("ocurri")
        items[ip.row].name = player.name
        items[ip.row].score = player.score
        print(items[ip.row].score)
        let cell = tableView.dequeueReusableCellWithIdentifier("ListItem", forIndexPath: ip)
        updateCellWithItem(cell, item: items[ip.row])
        self.tableView.reloadData()
        self.navigationController?.popViewControllerAnimated(true)
    }


}

