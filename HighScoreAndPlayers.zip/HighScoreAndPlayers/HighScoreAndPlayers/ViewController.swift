//
//  ViewController.swift
//  GuessGame
//
//  Created by T3ll0 on 3/14/16.
//  Copyright © 2016 E.V.I.L. All rights reserved.
//

import UIKit
protocol UsePlayerDelegate: class {
   
    func ModifyPlayerCancel(controller: ViewController,player: Player, ip:NSIndexPath)
}

class ViewController: UIViewController {
    var playero: Player!
    var UPD: UsePlayerDelegate!
    var ip: NSIndexPath!
    var targetValue :Int=0;
    var round :Int=0;
    var score:Int=0;
    @IBOutlet weak var roundLabel: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var randomNum: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    //Optionals investgate
    @IBOutlet weak var slider: UISlider!
    @IBAction func HitmePressed(sender: AnyObject) {
        print(slider.value)
        getScore();
        slider.value=50;
        //newRound();
        //setLabels();
        
    }
    
    func generateRandomNumber()->Void{
        targetValue = 1+Int(arc4random_uniform(100));
    }
    func newRound(){
        round+=1;
        generateRandomNumber();
    }
    func getScore(){
        let diference :Int=Int(slider.value)-targetValue;
        var scorep:Int;
        if(diference<0){
            scorep = (100 + diference);
        }else{
            scorep = (100 - diference);
        }
        score+=scorep;
        print(scorep,score);
        rateTry(scorep)
        
        
    }
    func rateTry(let diference:Int){
        var titleishon:String="";
        if (diference==100){
            titleishon="Perfect"
        }else{
            if(diference>80){
                titleishon="Nice"
            }else{
                if(diference>50){
                    titleishon="OK i guess"
                }else{
                    titleishon="Noob"                }
            }
        }
        let message = "You scored  \(diference) points";
        let alert = UIAlertController(title:titleishon,message: message,preferredStyle:UIAlertControllerStyle.Alert );
        let action = UIAlertAction(title: "Ok", style: .Default, handler:
            { myvar in
                self.newRound()
                self.setLabels()
        })
        alert.addAction(action)
        presentViewController(alert,animated: true, completion: nil)
        
    }
    
    
    
    @IBAction func sliderMoved(sender: AnyObject) {
        hellowWorldWithString(testo: "holo");
    }
    @IBAction func StartOverPress(sender: AnyObject) {
        if ( Int (scoreLabel.text!)! > playero.score){
            playero.score = Int (scoreLabel.text!)!
            UPD.ModifyPlayerCancel(self, player: playero, ip: ip)
            self.dismissViewControllerAnimated(true, completion: nil)
        }else{
            UPD.ModifyPlayerCancel(self, player: playero, ip: ip)
            self.dismissViewControllerAnimated(true, completion: nil)
        }
    }
    func setLabels(){
        randomNum.text = String(targetValue);//o tambien("\targetValue")
        roundLabel.text=String(round);
        scoreLabel.text=String(score);
    }
    //testo is the mane of the variable ouside the function
    func hellowWorldWithString( testo title:String) {
        //title is he name of the varible inside the function
        print(title);
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        round=0;
        score=0;
        slider.value=50;
        newRound();
        setLabels();
        nameLabel.text = playero.name
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
}

