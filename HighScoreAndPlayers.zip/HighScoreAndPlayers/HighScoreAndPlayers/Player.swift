//
//  Player.swift
//  HighScoreAndPlayers
//
//  Created by T3ll0 on 4/16/16.
//  Copyright © 2016 E.V.I.L. All rights reserved.
//

import Foundation
class Player {
    var name = "";
    var score = 0;
    
}